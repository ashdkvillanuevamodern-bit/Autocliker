package com.example.autoclicker

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.LinearLayout
import android.widget.TextView

class AutoClickService : AccessibilityService() {

    private class Target(val view: TextView, val lp: WindowManager.LayoutParams)

    private lateinit var wm: WindowManager
    private val handler = Handler(Looper.getMainLooper())
    private val targets = mutableListOf<Target>()
    private var panel: LinearLayout? = null
    private var info: TextView? = null
    private var playBtn: TextView? = null
    private var running = false
    private var intervalMs = 200L
    private var next = 0

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun params(w: Int, h: Int, x: Int, y: Int) = WindowManager.LayoutParams(
        w, h,
        WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
        PixelFormat.TRANSLUCENT
    ).apply { gravity = Gravity.TOP or Gravity.START; this.x = x; this.y = y }

    private fun drag(handle: View, lp: WindowManager.LayoutParams, moved: View) {
        var sx = 0; var sy = 0; var tx = 0f; var ty = 0f
        handle.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = lp.x; sy = lp.y; tx = e.rawX; ty = e.rawY }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = sx + (e.rawX - tx).toInt()
                    lp.y = sy + (e.rawY - ty).toInt()
                    wm.updateViewLayout(moved, lp)
                }
            }
            true
        }
    }

    private fun btn(label: String, onClick: () -> Unit) = TextView(this).apply {
        text = label
        setTextColor(Color.WHITE)
        textSize = 18f
        gravity = Gravity.CENTER
        setPadding(dp(10), dp(8), dp(10), dp(8))
        setOnClickListener { onClick() }
    }

    override fun onServiceConnected() {
        if (panel != null) return
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        buildPanel()
        addTarget()
    }

    private fun buildPanel() {
        val p = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = GradientDrawable().apply {
                setColor(Color.argb(225, 30, 30, 40)); cornerRadius = dp(24).toFloat()
            }
            setPadding(dp(6), dp(2), dp(6), dp(2))
        }
        val lp = params(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT, dp(12), dp(120)
        )
        val handle = btn("✥") {}
        drag(handle, lp, p)
        val play = btn("▶") { if (running) stop() else start() }
        val inf = TextView(this).apply { setTextColor(Color.WHITE); textSize = 12f; setPadding(dp(6), 0, dp(6), 0) }

        p.addView(handle)
        p.addView(play)
        p.addView(btn("＋") { addTarget() })
        p.addView(btn("－") { removeTarget() })
        p.addView(btn("🐢") { intervalMs = (intervalMs * 3 / 2).coerceAtMost(60_000L); refresh() })
        p.addView(btn("🐇") { intervalMs = (intervalMs * 2 / 3).coerceAtLeast(60L); refresh() })
        p.addView(inf)
        p.addView(btn("✕") { disableSelf() })

        panel = p; info = inf; playBtn = play
        wm.addView(p, lp)
        refresh()
    }

    private fun addTarget() {
        if (running) return
        val size = dp(48)
        val v = TextView(this).apply {
            text = "${targets.size + 1}"
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            textSize = 16f
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.argb(120, 255, 60, 60))
                setStroke(dp(2), Color.WHITE)
            }
        }
        val off = targets.size * dp(30)
        val lp = params(size, size, dp(120) + off, dp(300) + off)
        drag(v, lp, v)
        wm.addView(v, lp)
        targets += Target(v, lp)
        refresh()
    }

    private fun removeTarget() {
        if (running) return
        val t = targets.removeLastOrNull() ?: return
        runCatching { wm.removeView(t.view) }
        refresh()
    }

    private fun refresh() {
        info?.text = "${targets.size} • ${intervalMs}ms"
        playBtn?.text = if (running) "■" else "▶"
    }

    private fun setTouchable(touchable: Boolean) {
        targets.forEach {
            it.lp.flags = if (touchable) it.lp.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
            else it.lp.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
            it.view.alpha = if (touchable) 1f else 0.35f
            runCatching { wm.updateViewLayout(it.view, it.lp) }
        }
    }

    private fun start() {
        if (targets.isEmpty()) return
        running = true
        next = 0
        setTouchable(false)   // let gestures pass through the crosshairs
        refresh()
        handler.post(tick)
    }

    private fun stop() {
        running = false
        handler.removeCallbacks(tick)
        setTouchable(true)
        refresh()
    }

    private val tick = object : Runnable {
        override fun run() {
            if (!running || targets.isEmpty()) return
            val t = targets[next % targets.size]
            next++
            val loc = IntArray(2)
            t.view.getLocationOnScreen(loc)
            val path = Path().apply { moveTo(loc[0] + t.view.width / 2f, loc[1] + t.view.height / 2f) }
            val gesture = GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(path, 0, 40))
                .build()
            dispatchGesture(gesture, null, null)
            handler.postDelayed(this, intervalMs)
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() { if (panel != null) stop() }

    override fun onDestroy() {
        running = false
        handler.removeCallbacksAndMessages(null)
        targets.forEach { runCatching { wm.removeView(it.view) } }
        targets.clear()
        panel?.let { runCatching { wm.removeView(it) } }
        panel = null
        super.onDestroy()
    }
}
