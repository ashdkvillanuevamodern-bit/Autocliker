package com.example.autoclicker

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (24 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(pad, pad, pad, pad)
        }
        root.addView(TextView(this).apply {
            textSize = 16f
            text = "1. Tap the button below and turn ON \"Auto Clicker\" in Accessibility.\n\n" +
                "2. A floating panel appears over every app.\n\n" +
                "• ✥ drag the panel\n• ▶ start / ■ stop\n• ＋ / － add / remove tap targets (drag them where you want)\n" +
                "• 🐢 / 🐇 slower / faster\n• ✕ close\n\n" +
                "Targets are tapped in order, over and over, until you press ■."
        })
        root.addView(Button(this).apply {
            text = "Open Accessibility Settings"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        setContentView(root)
    }
}
